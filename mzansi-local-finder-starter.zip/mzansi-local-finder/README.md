# Mzansi Local Finder — starter website

## Included
- Responsive single-page website for phones and desktop
- Search and filters by keyword, area and category
- Business listing request form
- Advertising enquiry call-to-action
- Fictional demo listings clearly labelled as examples
- Browser-only request saving (localStorage)

## Important limitations
This is a front-end starter. Requests saved in localStorage stay in that browser/device and are not sent to you or stored in a shared database. The email button opens an email draft but has no recipient configured. There is no login, moderation dashboard, secure backend, or payment processing. Do not advertise demo listings as real businesses.

## Publish for free with GitHub Pages
1. Sign in or create an account at https://github.com.
2. Create a new public repository named `mzansi-local-finder`.
3. Upload `index.html` from this folder to the repository root.
4. Open the repository's Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch; select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish. Your public URL will be shown in Settings → Pages (usually `https://YOUR-USERNAME.github.io/mzansi-local-finder/`).
7. Open the URL on your phone and test search, filters, and forms.

## Alternative: Netlify Drop
Open https://app.netlify.com/drop in a browser, sign in if prompted, and upload the folder or a ZIP containing `index.html`. Follow the current prompts to publish. Free plan terms can change.

## Before launch
- Replace the fictional demo entries in the `businesses` array inside `index.html` with listings whose owners have agreed to be included.
- Add a real contact email to the form's email workflow or connect a form/backend service.
- If you want shared submissions, accounts, listing moderation, analytics, or ad billing, connect a backend/database and review the provider's free-plan limits and privacy terms.
- Label paid placements as advertisements and disclose sponsored listings clearly.
